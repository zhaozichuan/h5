1. minchart.html 分时页面
minchart.html?symbol=300150
参数
symbol 代码

2. kchart.html k线页面
minchart.html?symbol=300150&period=100
参数
symbol 代码
period 周期 100 日线，200周线，300月线



